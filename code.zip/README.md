-Install packages
npm install
-Test
npm run test
-Build
npm run build
-Run to server
npm start