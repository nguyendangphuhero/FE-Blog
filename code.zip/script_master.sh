source ./script_install_packages.sh
source ./script_install_dependencies.sh
source ./script_run_project.sh
