export { default as CreatePostPage } from './CreatePostPage';
