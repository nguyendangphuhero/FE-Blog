import React from 'react';
//import { Link, NavLink } from 'react-router-dom';

const Category = () => (
    <div >
       Category
    </div>
);

export default Category;